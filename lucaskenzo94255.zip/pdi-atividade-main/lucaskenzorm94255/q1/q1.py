import cv2

cap = cv2.VideoCapture("q1A.mp4")


while True:
    ret, frame = cap.read()

    if not ret:
        break
    
    # Seu código aqui.......
    import cv2
    import numpy as np

    video_path = "q1B.mp4"
    cap = cv2.VideoCapture(video_path)


    def detectar_formas(frame):

        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)


        limites_cores = {
            "vermelho": ([0, 120, 70], [10, 255, 255]),
            "azul": ([90, 50, 50], [130, 255, 255]),
            "verde": ([40, 50, 50], [80, 255, 255]),
        }

        contornos_detectados = []

        for cor, (lower, upper) in limites_cores.items():
            lower = np.array(lower, dtype=np.uint8)
            upper = np.array(upper, dtype=np.uint8)
            mask = cv2.inRange(hsv, lower, upper)

            contornos, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for contorno in contornos:
                area = cv2.contourArea(contorno)
                if area > 500:
                    contornos_detectados.append((contorno, area, cor))

        return contornos_detectados


    def identificar_maior_forma(contornos):

        if not contornos:
            return None
        return max(contornos, key=lambda x: x[1])


    def detectar_colisao(contornos):

        for i in range(len(contornos)):
            for j in range(i + 1, len(contornos)):
                contorno1, _, _ = contornos[i]
                contorno2, _, _ = contornos[j]
                if cv2.boundingRect(contorno1) and cv2.boundingRect(contorno2):
                    x1, y1, w1, h1 = cv2.boundingRect(contorno1)
                    x2, y2, w2, h2 = cv2.boundingRect(contorno2)


                    if (x1 < x2 + w2 and x1 + w1 > x2 and
                            y1 < y2 + h2 and y1 + h1 > y2):
                        return True
        return False


    def verificar_ultrapassagem(maior_forma, outras_formas):

        if not maior_forma or not outras_formas:
            return False

        xM, yM, wM, hM = cv2.boundingRect(maior_forma[0])

        for contorno, _, _ in outras_formas:
            x, y, w, h = cv2.boundingRect(contorno)


            if (xM <= x and xM + wM >= x + w and
                    yM <= y and yM + hM >= y + h):
                return True
        return False


    while True:
        ret, frame = cap.read()
        if not ret:
            break

        contornos = detectar_formas(frame)
        maior_forma = identificar_maior_forma(contornos)


        for contorno, _, cor in contornos:
            cv2.drawContours(frame, [contorno], -1, (0, 255, 255), 2)  # Contorno em amarelo
            x, y, w, h = cv2.boundingRect(contorno)
            cv2.putText(frame, cor, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 2)


        if maior_forma:
            cv2.rectangle(frame, cv2.boundingRect(maior_forma[0]), (0, 255, 0), 3)
            cv2.putText(frame, "Maior Forma", (x, y - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)


        if detectar_colisao(contornos):
            cv2.putText(frame, "COLISÃO DETECTADA", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 3)


        outras_formas = [f for f in contornos if f != maior_forma]
        if verificar_ultrapassagem(maior_forma, outras_formas):
            cv2.putText(frame, "ULTRAPASSAGEM DETECTADA", (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 3)


        cv2.imshow("Feed", frame)


        key = cv2.waitKey(1) & 0xFF
        if key == 27:
            break

    cap.release()
    cv2.destroyAllWindows()

    cv2.imshow("Feed", frame)


    key = cv2.waitKey(1) & 0xFF
    if key == 27:
        break


cap.release()
cv2.destroyAllWindows()